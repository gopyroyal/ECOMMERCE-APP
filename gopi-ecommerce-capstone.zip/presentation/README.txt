This is a placeholder text-only presentation.
Open this file and build slides with:
- Architecture (ECS Fargate + ALB + RDS + S3 + CloudFront + Cognito)
- CI/CD (GitHub → CodePipeline → CodeBuild → ECS/S3)
- Security/Observability
- Demo Screenshots (replace placeholders)
